namespace ST10378552_ICETASK4
{
    public partial class Form1 : Form
    {

        public Form1()
        {
            InitializeComponent();
            calculator = new calculator();
            // Wire up event handlers using lambda expressions
            calculator.AdditionPerformed += (sender, result) => DisplayResult(result);
            calculator.SubtractionPerformed += (sender, result) => DisplayResult(result);
            calculator.MultiplicationPerformed += (sender, result) => DisplayResult(result);
            calculator.DivisionPerformed += (sender, result) => DisplayResult(result);

        }
        private void DisplayResult(double result)
        {
            textBoxResult.Text = result.ToString();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            double num1 = double.Parse(textBoxNum1.Text);
            double num2 = double.Parse(textBoxNum2.Text);
            calculator.PerformAddition(num1, num2);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            double num1 = double.Parse(textBoxNum1.Text);
            double num2 = double.Parse(textBoxNum2.Text);
            calculator.PerformSubtraction(num1, num2);
        }

        private void button3_Click(object sender, EventArgs e)
        {
            double num1 = double.Parse(textBoxNum1.Text);
            double num2 = double.Parse(textBoxNum2.Text);
            calculator.PerformMultiplication(num1, num2);
        }

        private void button4_Click(object sender, EventArgs e)
        {
            double num1 = double.Parse(textBoxNum1.Text);
            double num2 = double.Parse(textBoxNum2.Text);
            calculator.PerformDivision(num1, num2);
        }

        public class Calculator
        {
            // Define delegate type
            public delegate void OperationPerformedEventHandler(object sender, double result);

            // Define events for each operation
            public event OperationPerformedEventHandler AdditionPerformed;
            public event OperationPerformedEventHandler SubtractionPerformed;
            public event OperationPerformedEventHandler MultiplicationPerformed;
            public event OperationPerformedEventHandler DivisionPerformed;

            // Methods for arithmetic operations
            public void PerformAddition(double num1, double num2)
            {
                double result = num1 + num2;
                AdditionPerformed?.Invoke(this, result); // Raise event
            }

            public void PerformSubtraction(double num1, double num2)
            {
                double result = num1 - num2;
                SubtractionPerformed?.Invoke(this, result); // Raise event
            }

            public void PerformMultiplication(double num1, double num2)
            {
                double result = num1 * num2;
                MultiplicationPerformed?.Invoke(this, result); // Raise event
            }

            public void PerformDivision(double num1, double num2)
            {
                if (num2 == 0)
                {
                    throw new ArgumentException("Cannot divide by zero.");
                }
                double result = num1 / num2;
                DivisionPerformed?.Invoke(this, result); // Raise event
            }
        }
    }
}
