﻿namespace ST10378552_ICETASK4
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            textBoxNum1 = new TextBox();
            textBoxNum2 = new TextBox();
            textBoxResult = new TextBox();
            button1 = new Button();
            button2 = new Button();
            button3 = new Button();
            button4 = new Button();
            label1 = new Label();
            SuspendLayout();
            // 
            // textBoxNum1
            // 
            textBoxNum1.Location = new Point(333, 154);
            textBoxNum1.Name = "textBoxNum1";
            textBoxNum1.Size = new Size(125, 27);
            textBoxNum1.TabIndex = 0;
            // 
            // textBoxNum2
            // 
            textBoxNum2.Location = new Point(487, 154);
            textBoxNum2.Name = "textBoxNum2";
            textBoxNum2.Size = new Size(125, 27);
            textBoxNum2.TabIndex = 1;
            // 
            // textBoxResult
            // 
            textBoxResult.Location = new Point(375, 380);
            textBoxResult.Name = "textBoxResult";
            textBoxResult.Size = new Size(160, 27);
            textBoxResult.TabIndex = 2;
            // 
            // button1
            // 
            button1.Location = new Point(178, 255);
            button1.Name = "button1";
            button1.Size = new Size(113, 54);
            button1.TabIndex = 3;
            button1.Text = "Add";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // button2
            // 
            button2.Location = new Point(356, 257);
            button2.Name = "button2";
            button2.Size = new Size(102, 53);
            button2.TabIndex = 4;
            button2.Text = "Subtract";
            button2.UseVisualStyleBackColor = true;
            button2.Click += button2_Click;
            // 
            // button3
            // 
            button3.Location = new Point(507, 258);
            button3.Name = "button3";
            button3.Size = new Size(118, 52);
            button3.TabIndex = 5;
            button3.Text = "Multiply";
            button3.UseVisualStyleBackColor = true;
            button3.Click += button3_Click;
            // 
            // button4
            // 
            button4.Location = new Point(676, 257);
            button4.Name = "button4";
            button4.Size = new Size(115, 52);
            button4.TabIndex = 6;
            button4.Text = "Divide";
            button4.UseVisualStyleBackColor = true;
            button4.Click += button4_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(426, 54);
            label1.Name = "label1";
            label1.Size = new Size(76, 20);
            label1.TabIndex = 7;
            label1.Text = "Calculator";
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.ActiveCaption;
            ClientSize = new Size(948, 501);
            Controls.Add(label1);
            Controls.Add(button4);
            Controls.Add(button3);
            Controls.Add(button2);
            Controls.Add(button1);
            Controls.Add(textBoxResult);
            Controls.Add(textBoxNum2);
            Controls.Add(textBoxNum1);
            ForeColor = SystemColors.MenuHighlight;
            Name = "Form1";
            Text = "Form1";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox textBoxNum1;
        private TextBox textBoxNum2;
        private TextBox textBoxResult;
        private Button button1;
        private Button button2;
        private Button button3;
        private Button button4;
        private Label label1;
    }
}
